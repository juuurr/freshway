package com.example.chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgentBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
